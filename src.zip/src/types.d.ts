declare module 'graphql/error/GraphQLError';
declare module 'graphql/language/ast';