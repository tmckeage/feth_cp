import {Component, OnInit} from '@angular/core';
import { Router } from '@angular/router';
import { EquipmentService } from 'src/app/services/equipment.service';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';


@Component({
	selector: 'app-review',
	templateUrl: './review.component.html',
	styleUrls: ['./review.component.scss']
})
export class ReviewComponent implements OnInit {
	fathomUserDetails: any;
	scanners: any;
	facilityName:any;
	roomName:any;
	typeName:any;
	selectedFacility: any = 0;
	selectedRoom: any = 0 ;
	selectedType: any = 0;
	selectedSn: any = "";
	viewData: any;
	closeResult: any;
	date:any;
	isFinalized: boolean = false;
	isImg: boolean = false;
	isNote: boolean = false;
	snResult:any;
	isComplete:boolean = false;
	isSubStudyFlag: boolean = false;
	physicalCondition:any[] = [];
	displayEvaluations:any[] = [];
    review:any;
	reviewList :any[] = [];
	reviewData :any;
	assessmentType:any;
	reasonTextArea:any;
	scannerAcceptance:any;
	transducerPhysicalCondition = [];
	imagingList:any;
	noteValue:any;
	titleName:any;
	isfinalized:any;

	constructor(private modalService: NgbModal, private router: Router, private equipmentService:EquipmentService) { }
 
	ngOnInit(): void {
    	// check login session
    	this.fathomUserDetails = sessionStorage.fathomUserDetails ? JSON.parse(sessionStorage.fathomUserDetails) : '';
		if (!this.fathomUserDetails.username) {
			this.router.navigate(['']);
		}
     	// show for dropDown list
		this.scanners = this.equipmentService.getScanner();
		this.scanners.forEach((res: any)=>{
          this.isfinalized = res.last_study;
		});
		this.roomName = this.equipmentService.roomTransducer;
		this.facilityName = this.equipmentService.facilityTransducer;
		this.typeName = this.equipmentService.typeTransducer;
		
 	}
	
	// equipment filter
	equipmentFilter() {
		let scannerList = this.equipmentService.getScanner();
		// facility filter
		if (this.selectedFacility != 0) {
		    scannerList = scannerList.filter(item => {
				return item.facility === this.selectedFacility;
			});
		}
		// room filter
		if (this.selectedRoom != 0) {
		    scannerList = scannerList.filter(item => {
				return item.room === this.selectedRoom;
			});
		}
	    // type filter
		if (this.selectedType != 0) {
			scannerList = scannerList.filter(item => {
				return item.last_study == this.selectedType;
			});
		}
		// s/n searching
		if (this.selectedSn != "") {
			scannerList = scannerList.filter(item => {
				return item.serial_number == this.selectedSn;
			});
		}
		this.scanners = scannerList;
	}

	// on scanner click open view modal
	scannerDetail(scanner: any, scannerView: any) {
		this.titleName = 'Scanner Acceptance Study';
		this.viewData = scanner.make;
		this.date = '07/10/2021';
		this.isImg = false;
		this.isNote = false;
		this.isFinalized = false;
		if (scanner.last_study.finalized === "true") {
			this.isFinalized = true;     
		} 
		this.reviewList = scanner.last_study.data;
		this.scanners.last_study.data.forEach((element: any) => {
			this.reviewList = Object.entries(element).map(([type, value]) => ({type, value}));
			this.reviewList.forEach((res: any)=>{
				this.physicalCondition  = res.value;
			   });
			});
		this.modalService.open(scannerView, { ariaLabelledBy: 'modal-basic-title' }).result.then((result) => {
			this.closeResult = `Closed with: ${result}`;
		});
	}

	getKeys(list: any) : Array<string> {
		return Object.keys(list);
	}

	// sub study icon clicking open model
	subStudy (subStudyView: any, review: any){
		this.scannerAcceptance = review;
		this.scanners.forEach((item: any) => {
        this.noteValue = item.last_study.data.physical.control_panel.notes[0].text;
	    });
		if (this.isImg === true || this.isNote === true) {
			this.isSubStudyFlag = true;
		}
		// this.modalService.dismissAll();
		this.modalService.open(subStudyView, { ariaLabelledBy: 'modal-basic-title',size:'lg' }).result.then((result) => {
			this.closeResult = `Closed with: ${result}`;
		});
	}

    // reason for change type
	onSubStudy(isSubStudyAvailable: any, e:any, value: any){
		this.assessmentType = e.target.value;
		this.review = value;
		setTimeout(()=>{   
			// this.modalService.dismissAll();
			this.modalService.open(isSubStudyAvailable, { ariaLabelledBy: 'modal-basic-title',size:'md' }).result.then((result) => {
				this.closeResult = `Closed with: ${result}`;
			});	
		}, 1000);
	}
   
	reason(reason: any){ 
		console.log(reason);
	}
	
    // transducer detail
	onTransducerDetail(transducer: any, scannerView: any) {
		this.titleName = 'Transducer Acceptance Study';
		this.viewData = transducer.make;
		this.date = '07/10/2021';
		this.viewData = transducer.make;
		this.date = '07/10/2021';
		this.reviewData = '';
		this.reviewData = transducer.last_study;
		// if finalized flag check
		// if (data.finalized === "true") {
		// 	this.isFinalized = true;     
		// }
		// this.reviewData.forEach((res: any)=>{
		// 	res.data.forEach((item: any)=>{
		// 	   this.reviewList = Object.entries(item).map(([type, value]) => ({type, value}));
		// 	   this.reviewList.forEach((res: any)=>{
		// 		   let object = Object.entries(res.value).map(([type, value]) => ({type, value}));
		// 		   object.forEach((data: any) => {
		// 		   this.physicalCondition = Object.entries(data.value).map(([type, value]) => ({type, value}));
		// 		   //this.physicalCondition = this.physicalCondition.replaceAll('_', " ");
   
		// 		   });
		// 	   });
		// 	});
		//    });

		this.modalService.open(scannerView, {ariaLabelledBy: 'modal-basic-title' }).result.then((result) => {
			this.closeResult = `Closed with: ${result}`;
		});
	}
}
function _(_: any, arg1: string): any {
	throw new Error('Function not implemented.');
}

